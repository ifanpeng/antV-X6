import React, { Component } from 'react'
import '../../css/minimap.css'
export default class miniMap extends Component {
   
    render() {
        return (
            <div className="map"></div>
        )
    }
}
